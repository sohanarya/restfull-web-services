package com.einfochips.rest.webservices.restfullwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfullWebServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
